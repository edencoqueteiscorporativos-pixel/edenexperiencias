# ÉDEN EXPERIÊNCIAS GASTRONÔMICAS
## Instalação do sistema compartilhado · Duas administradoras

Este pacote foi preparado para o projeto Supabase da Éden. A aplicação utiliza a URL e a **publishable key** fornecidas para esse projeto. Essas credenciais são públicas por natureza e a segurança depende da autenticação e de **Row Level Security (RLS)** no banco de dados.

**Importante:** o banco ainda precisa ser criado por você no Supabase e o site precisa ser publicado. Não foram alterados dados do seu projeto remoto. Não use esses SQLs no projeto da agência ou em qualquer banco que já contenha tabelas da Éden: eles foram feitos para a instalação inicial em um projeto Supabase dedicado.

## 1. Crie as tabelas e as regras de acesso

1. Acesse https://supabase.com/dashboard e selecione o projeto **Éden**.
2. Acesse **SQL Editor → New query**.
3. Abra `supabase/01_BANCO_E_SEGURANCA.sql` em um editor de texto, copie TODO o conteúdo e cole no SQL Editor.
4. Clique em **Run**. Aguarde e confirme que não houve erro.
5. No **Table Editor**, verifique se surgiram tabelas como `clients`, `events`, `eden_admins`, `obligations`, `recipes` e `purchases`.

Esse SQL estabelece acesso RLS exclusivo aos administradores aprovados, histórico de alterações, validações financeiras e publicação das tabelas no Realtime. Não cria usuários ou senhas.

## 2. Crie os dois logins separadamente

No **Supabase → Authentication → Users → Add user**, crie os dois usuários abaixo (pode aparecer opção **Create new user**):

- `larathassia@gmail.com`
- `amandiisouza@icloud.com`

Defina uma senha provisória FORTE E DIFERENTE para cada conta, ou envie um convite se preferir que a pessoa defina a própria senha. **Não utilize a senha compartilhada no chat.** Se usar convites, certifique-se de que o link de convite abre uma página HTTPS configurada nas URLs de redirecionamento do Supabase; só então conclua a ativação. Com contas criadas manualmente, a entrada por e-mail e senha é mais direta.

- Marque a confirmação de e-mail apenas se tiver certeza de que o endereço pertence à responsável, ou use o fluxo de verificação por e-mail.
- Mantenha o login por e-mail habilitado.
- Após criar ambas as contas, em **Authentication → Settings**, desative **Allow new users to sign up** se não precisar de novos cadastros públicos. O login das contas existentes permanece disponível.
- Anote apenas se ambos os usuários aparecem em Authentication → Users. **Não me envie as senhas.**

## 3. Autorize exatamente os dois usuários

1. Abra `supabase/02_AUTORIZAR_DUAS_ADMINISTRADORAS.sql`.
2. Copie tudo, cole em uma **nova query** no SQL Editor e clique em **Run**.
3. Confirme se a consulta final mostra **2 linhas**, correspondendo aos e-mails acima.
4. Se aparecer mensagem informando que faltam contas, volte a Authentication → Users e crie as contas com os e-mails exatamente corretos. Execute o segundo SQL novamente depois.

**As duas administradoras poderão ver e editar dados criados pela outra.** Novas contas autenticadas não recebem acesso automaticamente. A autorização é feita por `auth.users.id` e pela tabela protegida `eden_admins`, não por uma senha em HTML.

## 4. Publique SOMENTE o site

O ZIP separado `EDEN_Site_Publicar_Vercel.zip` contém **apenas `index.html` e `vercel.json`**. Use ESSE ZIP, ou os dois arquivos da pasta `publicar/`, para publicar na Vercel.

- Acesse https://vercel.com/drop para um teste de publicação simples (consulte as condições do plano para uso comercial) ou importe um repositório privado do GitHub na Vercel.
- Arraste a pasta contendo `index.html` e `vercel.json`, ou importe pelo GitHub e selecione a pasta `publicar/` como raiz.
- Publique e abra o endereço HTTPS apresentado pela Vercel. Não há backend local nem comando de build.
- Não publique a pasta `supabase/`, os SQLs, senhas ou backups financeiros como arquivos estáticos no site.

### Não crie um segundo projeto de banco

O HTML já aponta para o Supabase da Éden, usando a Project URL e a publishable key informadas na conversa. Não é necessário colar essas informações novamente.

## 5. Teste com as duas contas em dispositivos diferentes

1. No primeiro computador, abra a URL publicada e entre com o e-mail da primeira administradora e sua senha.
2. Vá em **Clientes** e cadastre um cliente de teste, por exemplo `CLIENTE TESTE ÉDEN`.
3. No segundo aparelho, abra a MESMA URL usando o segundo e-mail e sua senha própria.
4. Verifique se o cliente aparece. Depois altere o nome em um aparelho e confirme se a outra tela atualiza.
5. Faça o mesmo com tarefa e oportunidade.
6. Crie uma **conta financeira** e um **lançamento de teste**. Verifique que o caixa **não é atualizado** só por criar uma obrigação. Ele muda quando o pagamento/recebimento é liquidado.
7. No menu lateral há **Alterar minha senha**, para cada administradora definir uma senha definitiva e individual.
8. Remova os dados de teste antes de começar a operação real, considerando os registros de auditoria.

A tela mostra **Sincronização ativa** quando recebe `SUBSCRIBED` do canal Realtime. Isso confirma a conexão do canal, **não substitui o teste de gravação e visibilidade entre contas**.

## 6. Se houver erro

- **Seu login ainda não foi autorizado**: confira se o segundo SQL mostrou exatamente os dois e-mails e se entrou com a conta correta.
- **relation public.eden_admins does not exist**: o primeiro SQL não foi aplicado ou foi executado em outro projeto.
- **Permission denied / RLS**: confira se o segundo SQL foi executado e se a conta foi aprovada.
- **Conectando... permanente**: confirme se as tabelas constam na publicação `supabase_realtime` e que o navegador permite conexão WebSocket.
- **Invalid login credentials**: confirme e-mail, senha e eventual confirmação do endereço no Supabase.
- **Falta de alterações entre aparelhos**: atualize a página nos dois aparelhos para diferenciar problemas de Realtime de problemas de leitura e RLS. Confira SQL e console do navegador.

## Limitações desta fase

- Interface de administração e banco de dados compartilhado preparados, mas **sem validação end-to-end contra seu projeto Supabase real** até que você execute o SQL e crie os logins.
- Uso de Supabase Realtime por Postgres Changes para equipes pequenas. Pode ser migrado para Broadcast se escalar.
- Consultas da interface limitadas a 1.000 registros por tabela, sem paginação nesta versão.
- O backup JSON é exportação manual dos registros carregados pela interface, **não substitui backups/restauração testada** do banco Supabase.
- Ainda faltam anexos seguros no Storage, conciliação bancária, precificação com custos históricos congelados, tarefas/parcelas recorrentes e módulos avançados descritos no briefing original.
- Ações simultâneas e integridade de dados só podem ser definitivamente aprovadas após testes no banco real. Para uso com transações financeiras relevantes, valide com cuidado antes de adotar como fonte contábil oficial.

### Arquivos do pacote completo

- `publicar/index.html` — site com logo original, layout clean e cliente Supabase.
- `publicar/vercel.json` — configurações de hospedagem.
- `supabase/01_BANCO_E_SEGURANCA.sql` — estrutura, RLS, integridade e Realtime.
- `supabase/02_AUTORIZAR_DUAS_ADMINISTRADORAS.sql` — aprova os dois e-mails informados sem precisar copiar UUIDs.
- `LEIA_PRIMEIRO.md` — este manual.

**Segurança:** nunca coloque `service_role`, `sb_secret_`, senha do banco ou senha de usuária no HTML ou em repositório. Em sites estáticos, o código-fonte e a publishable key podem ser vistos por qualquer visitante; a proteção é feita pelo Supabase Auth, RLS e grants do banco.
