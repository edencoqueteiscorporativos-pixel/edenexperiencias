-- ÉDEN | Schema para um projeto Supabase DEDICADO à Éden.
-- Admins são explicitamente aprovadas por UUID. NÃO use este script no banco da agência.
create extension if not exists pgcrypto;

create table if not exists public.clients (
 id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users(id),
 name text not null, company text default '', contact text default '', phone text default '', email text default '',
 address text default '', notes text default '', created_at timestamptz not null default now()
);
create table if not exists public.opportunities (
 id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users(id),
 client_id uuid not null references public.clients(id), title text not null,
 stage text not null default 'novo_contato', service text default '', event_date date,
 guests integer default 0 check(guests>=0), estimated_value numeric(14,2) not null default 0 check(estimated_value>=0),
 last_contact_at date, followup_date date, next_action text default '', owner_name text default '',
 notes text default '', created_at timestamptz not null default now()
);
create table if not exists public.events (
 id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users(id),
 client_id uuid not null references public.clients(id), opportunity_id uuid unique references public.opportunities(id),
 name text not null, event_date date not null, start_time time, end_time time,
 venue text default '', address text default '', guests integer default 0 check(guests>=0),
 service text default '', status text not null default 'confirmado',
 contracted_amount numeric(14,2) not null default 0 check(contracted_amount>=0),
 estimated_cost numeric(14,2) not null default 0 check(estimated_cost>=0),
 notes text default '', created_at timestamptz not null default now()
);
create table if not exists public.tasks (
 id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users(id),
 title text not null, event_id uuid references public.events(id), client_id uuid references public.clients(id),
 assignee text default '', due_date date, priority text not null default 'normal',
 status text not null default 'pendente', notes text default '', created_at timestamptz not null default now()
);
create table if not exists public.accounts (
 id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users(id),
 name text not null, type text not null default 'banco', initial_balance numeric(14,2) not null default 0,
 created_at timestamptz not null default now()
);
create table if not exists public.obligations (
 id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users(id),
 kind text not null check(kind in ('receber','pagar')),
 client_id uuid references public.clients(id), event_id uuid references public.events(id),
 purchase_id uuid unique, counterparty text default '', description text not null,
 category text default 'geral', amount numeric(14,2) not null check(amount > 0),
 due_date date not null, canceled boolean not null default false,
 notes text default '', created_at timestamptz not null default now()
);
create table if not exists public.settlements (
 id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users(id),
 obligation_id uuid not null references public.obligations(id),
 account_id uuid not null references public.accounts(id),
 amount numeric(14,2) not null check(amount > 0), paid_on date not null,
 method text default 'pix', notes text default '',
 reversed_at timestamptz, reversal_reason text,
 created_at timestamptz not null default now()
);
create table if not exists public.transfers (
 id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users(id),
 from_account uuid not null references public.accounts(id), to_account uuid not null references public.accounts(id),
 amount numeric(14,2) not null check(amount>0), transferred_on date not null,
 notes text default '', created_at timestamptz not null default now(),
 check(from_account <> to_account)
);
create table if not exists public.ingredients (
 id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users(id),
 name text not null, category text default '', unit text not null default 'g' check(unit in ('g','ml','un')),
 pack_qty numeric(14,3) not null default 1 check(pack_qty>0),
 pack_price numeric(14,2) not null default 0 check(pack_price>=0),
 min_stock numeric(14,3) not null default 0 check(min_stock>=0),
 supplier text default '', created_at timestamptz not null default now()
);
create table if not exists public.recipes (
 id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users(id),
 name text not null, category text default '', yield_qty numeric(12,2) not null default 1 check(yield_qty>0),
 description text default '', instructions text default '', prep_minutes int default 0,
 photo_url text default '', created_at timestamptz not null default now()
);
create table if not exists public.recipe_items (
 id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users(id),
 recipe_id uuid not null references public.recipes(id) on delete cascade,
 ingredient_id uuid not null references public.ingredients(id),
 qty numeric(14,3) not null check(qty>0), unique(recipe_id,ingredient_id)
);
create table if not exists public.menus (
 id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users(id),
 name text not null, client_id uuid references public.clients(id), event_id uuid references public.events(id),
 guests integer default 1 check(guests>0), price numeric(14,2) not null default 0 check(price>=0),
 description text default '', notes text default '', version integer not null default 1,
 created_at timestamptz not null default now()
);
create table if not exists public.menu_items (
 id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users(id),
 menu_id uuid not null references public.menus(id) on delete cascade,
 recipe_id uuid not null references public.recipes(id),
 portions numeric(14,2) not null default 1 check(portions>0), sort_order int default 0,
 unique(menu_id,recipe_id)
);
create table if not exists public.purchases (
 id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users(id),
 ingredient_id uuid not null references public.ingredients(id), event_id uuid references public.events(id),
 supplier text default '', qty numeric(14,3) not null check(qty>0),
 unit_price numeric(14,6) not null default 0 check(unit_price>=0),
 purchase_date date not null, status text not null default 'planejada' check(status in ('planejada','confirmada')),
 notes text default '', created_at timestamptz not null default now()
);
alter table public.obligations drop constraint if exists obligations_purchase_id_fkey;
alter table public.obligations add constraint obligations_purchase_id_fkey foreign key (purchase_id) references public.purchases(id);
create table if not exists public.stock_movements (
 id uuid primary key default gen_random_uuid(), user_id uuid not null default auth.uid() references auth.users(id),
 ingredient_id uuid not null references public.ingredients(id), event_id uuid references public.events(id),
 purchase_id uuid unique references public.purchases(id),
 qty numeric(14,3) not null check(qty <> 0),
 reason text not null default 'ajuste', movement_date date not null default current_date,
 notes text default '', created_at timestamptz not null default now()
);
create table if not exists public.audit_logs (
 id bigint generated always as identity primary key, user_id uuid not null references auth.users(id),
 table_name text not null, record_id uuid, action text not null,
 previous jsonb, current jsonb, changed_at timestamptz not null default now()
);



-- Somente as administradoras cadastradas por UUID no passo 2 têm acesso.
-- Sem política de INSERT/UPDATE/DELETE, não é possível criar administradoras pelo navegador.
create table if not exists public.eden_admins (
 user_id uuid primary key references auth.users(id) on delete cascade,
 display_name text not null default '',
 created_at timestamptz not null default now()
);
alter table public.eden_admins enable row level security;
drop policy if exists eden_admin_self_read on public.eden_admins;
create policy eden_admin_self_read on public.eden_admins for select to authenticated using (user_id = (select auth.uid()));
revoke all on public.eden_admins from anon, authenticated;
grant select on public.eden_admins to authenticated;

-- RLS verifica a presença do ID em eden_admins, NÃO o e-mail nem a chave pública.
-- SECURITY DEFINER contorna recursão de RLS da tabela de administradoras.
create or replace function public.is_eden_admin()
returns boolean language sql stable security definer
set search_path = '' as $$
 select exists (select 1 from public.eden_admins where user_id = (select auth.uid()));
$$;
revoke all on function public.is_eden_admin() from public;
grant execute on function public.is_eden_admin() to authenticated;

do $$ declare t text; begin
 foreach t in array array['clients','opportunities','events','tasks','accounts','obligations','settlements','transfers','ingredients','recipes','recipe_items','menus','menu_items','purchases','stock_movements','audit_logs'] loop
   execute format('alter table public.%I enable row level security',t);
   if t <> 'audit_logs' then
     execute format('drop policy if exists eden_admin_access on public.%I',t);
     execute format('create policy eden_admin_access on public.%I for all to authenticated using ((select public.is_eden_admin())) with check ((select public.is_eden_admin()))',t);
     -- Criadoras são identificadas por user_id, mas registros pertencem à empresa.
   else
     execute 'drop policy if exists eden_admin_audit_read on public.audit_logs';
     execute 'create policy eden_admin_audit_read on public.audit_logs for select to authenticated using ((select public.is_eden_admin()))';
   end if;
 end loop;
end $$;
-- Bloqueia leitura/escrita a visitantes não autenticados, mesmo conhecendo a URL/chave pública.
revoke all on all tables in schema public from anon;
-- Necessário ao SDK autenticado. A RLS controla as linhas visíveis.
grant select, insert, update, delete on public.clients,public.opportunities,public.events,public.tasks,
 public.accounts,public.obligations,public.settlements,public.transfers,public.ingredients,
 public.recipes,public.recipe_items,public.menus,public.menu_items,public.purchases,
 public.stock_movements to authenticated;
grant select on public.audit_logs to authenticated;
grant usage, select on sequence public.audit_logs_id_seq to authenticated;

-- Garante que user_id identifica a autora original, não um nome que pode ser forjado.
create or replace function public.keep_creator_identity() returns trigger
language plpgsql set search_path = public as $$
begin
 if tg_op='INSERT' then
   if auth.uid() is null or new.user_id is distinct from auth.uid() then
     raise exception 'Autoria inválida para este registro';
   end if;
 elsif new.user_id is distinct from old.user_id then
   raise exception 'Não é permitido alterar a autoria de registros existentes';
 end if;
 return new;
end $$;
do $$ declare t text; begin
 foreach t in array array['clients','opportunities','events','tasks','accounts','obligations','settlements','transfers','ingredients','recipes','recipe_items','menus','menu_items','purchases','stock_movements'] loop
   execute format('drop trigger if exists trg_keep_creator on public.%I',t);
   execute format('create trigger trg_keep_creator before insert or update on public.%I for each row execute function public.keep_creator_identity()',t);
 end loop;
end $$;

-- Vinculações internas sempre se referem a registros existentes, mesmo que criados
-- pela outra administradora. A integridade principal continua garantida pelas FKs.
create or replace function public.check_eden_references() returns trigger
language plpgsql security definer set search_path = public as $$
declare col text; ref_table text; referenced uuid; exists_record boolean;
begin
 if not public.is_eden_admin() then raise exception 'Acesso não autorizado'; end if;
 for col, ref_table in select * from (values
   ('client_id','clients'),('event_id','events'),('opportunity_id','opportunities'),
   ('recipe_id','recipes'),('ingredient_id','ingredients'),('menu_id','menus'),
   ('obligation_id','obligations'),('account_id','accounts'),
   ('from_account','accounts'),('to_account','accounts'),('purchase_id','purchases')
 ) as x(col,ref_table) loop
   if to_jsonb(new) ? col then
     referenced := nullif(to_jsonb(new)->>col,'')::uuid;
     if referenced is not null then
       execute format('select exists(select 1 from public.%I where id = $1)',ref_table)
         into exists_record using referenced;
       if not exists_record then raise exception 'Referência inexistente em %',col; end if;
     end if;
   end if;
 end loop;
 return new;
end $$;
do $$ declare t text; begin
 foreach t in array array['opportunities','events','tasks','obligations','settlements','transfers','recipe_items','menus','menu_items','purchases','stock_movements'] loop
   execute format('drop trigger if exists trg_eden_refs on public.%I',t);
   execute format('create trigger trg_eden_refs before insert or update on public.%I for each row execute function public.check_eden_references()',t);
 end loop;
end $$;

-- Conserva obrigações conciliadas: nunca reduzir abaixo do total quitado ou cancelar
-- sem estornar as liquidações.
create or replace function public.validate_obligation() returns trigger language plpgsql
security definer set search_path=public as $$
declare received numeric;
begin
 if not public.is_eden_admin() then raise exception 'Acesso não autorizado'; end if;
 if tg_op='UPDATE' then
   select coalesce(sum(amount),0) into received from public.settlements
   where obligation_id=new.id and reversed_at is null;
   if new.amount < received then raise exception 'Valor inferior ao já liquidado'; end if;
   if old.kind is distinct from new.kind and received>0 then raise exception 'Tipo financeiro liquidado não pode mudar'; end if;
   if new.canceled and received>0 then raise exception 'Estorne as liquidações antes de cancelar'; end if;
 end if;
 return new;
end $$;
drop trigger if exists trg_validate_obligation on public.obligations;
create trigger trg_validate_obligation before update on public.obligations
 for each row execute function public.validate_obligation();

-- Bloqueio FOR UPDATE da conta evita pagamento excedente em operações simultâneas.
create or replace function public.validate_settlement() returns trigger language plpgsql
security definer set search_path=public as $$
declare billed record; already numeric;
begin
 if not public.is_eden_admin() then raise exception 'Acesso não autorizado'; end if;
 select id,amount,canceled into billed from public.obligations where id=new.obligation_id for update;
 if not found or billed.canceled then raise exception 'Conta inválida ou cancelada'; end if;
 select coalesce(sum(amount),0) into already from public.settlements
   where obligation_id=new.obligation_id and reversed_at is null;
 if already+new.amount > billed.amount+0.0001 then raise exception 'Pagamento superior ao saldo pendente'; end if;
 return new;
end $$;
drop trigger if exists trg_validate_settlement on public.settlements;
create trigger trg_validate_settlement before insert on public.settlements
 for each row execute function public.validate_settlement();
revoke update,delete on public.settlements from authenticated;

-- Estorno preserva histórico, inclusive se quem pagou foi a outra responsável.
create or replace function public.reverse_settlement(p_id uuid,p_reason text) returns void
language plpgsql security definer set search_path=public as $$
begin
 if not public.is_eden_admin() then raise exception 'Acesso não autorizado'; end if;
 if length(trim(coalesce(p_reason,'')))<3 then raise exception 'Informe o motivo do estorno'; end if;
 update public.settlements set reversed_at=now(),reversal_reason=p_reason
 where id=p_id and reversed_at is null;
 if not found then raise exception 'Liquidação não encontrada ou já estornada'; end if;
end $$;
revoke all on function public.reverse_settlement(uuid,text) from public;
grant execute on function public.reverse_settlement(uuid,text) to authenticated;

-- Compra confirmada cria obrigação + estoque em uma só transação (nunca duas vezes).
create or replace function public.confirm_purchase(p_id uuid) returns void
language plpgsql security definer set search_path=public as $$
declare p public.purchases%rowtype; ing public.ingredients%rowtype;
begin
 if not public.is_eden_admin() then raise exception 'Acesso não autorizado'; end if;
 select * into p from public.purchases where id=p_id for update;
 if not found then raise exception 'Compra não encontrada'; end if;
 if p.status='confirmada' then return; end if;
 select * into ing from public.ingredients where id=p.ingredient_id;
 if not found then raise exception 'Ingrediente inválido'; end if;
 if p.qty*p.unit_price<=0 then raise exception 'Informe o valor real da compra'; end if;
 perform set_config('eden.confirming_purchase','yes',true);
 update public.purchases set status='confirmada' where id=p.id;
 insert into public.obligations(user_id,kind,event_id,purchase_id,counterparty,description,category,amount,due_date)
 values(auth.uid(),'pagar',p.event_id,p.id,p.supplier,'Compra: '||ing.name,'ingredientes',round(p.qty*p.unit_price,2),p.purchase_date)
 on conflict(purchase_id) do nothing;
 insert into public.stock_movements(user_id,ingredient_id,event_id,purchase_id,qty,reason,movement_date)
 values(auth.uid(),p.ingredient_id,p.event_id,p.id,p.qty,'compra',p.purchase_date)
 on conflict(purchase_id) do nothing;
 update public.ingredients set pack_price=round(p.unit_price*pack_qty,2),supplier=coalesce(nullif(p.supplier,''),supplier)
 where id=ing.id;
 perform set_config('eden.confirming_purchase','',true);
end $$;
revoke all on function public.confirm_purchase(uuid) from public;
grant execute on function public.confirm_purchase(uuid) to authenticated;

-- Não é permitido marcar compra como confirmada fora da RPC protegida.
create or replace function public.guard_purchase_confirmation() returns trigger language plpgsql as $$
begin
 if tg_op='INSERT' then
   if new.status='confirmada' then raise exception 'Crie como planejada e confirme pela operação protegida'; end if;
   return new;
 end if;
 if old.status='confirmada' and new is distinct from old then
   raise exception 'Compra confirmada é histórica; registre correção separadamente';
 end if;
 if old.status <> 'confirmada' and new.status='confirmada'
    and current_setting('eden.confirming_purchase',true) is distinct from 'yes' then
   raise exception 'Confirme pelo procedimento protegido confirm_purchase';
 end if;
 return new;
end $$;
drop trigger if exists trg_guard_purchase on public.purchases;
create trigger trg_guard_purchase before insert or update on public.purchases
 for each row execute function public.guard_purchase_confirmation();
create or replace function public.guard_purchase_link() returns trigger language plpgsql as $$
begin
 if new.purchase_id is not null and current_setting('eden.confirming_purchase',true) is distinct from 'yes' then
   raise exception 'O vínculo de compra é criado pelo procedimento protegido';
 end if;
 return new;
end $$;
drop trigger if exists trg_obligation_purchase_link on public.obligations;
create trigger trg_obligation_purchase_link before insert or update of purchase_id on public.obligations
 for each row execute function public.guard_purchase_link();
drop trigger if exists trg_stock_purchase_link on public.stock_movements;
create trigger trg_stock_purchase_link before insert or update of purchase_id on public.stock_movements
 for each row execute function public.guard_purchase_link();
revoke delete on public.obligations,public.purchases,public.transfers,public.stock_movements from authenticated;

-- Audit log separado da autoria original, registra QUEM alterou cada registro.
create or replace function public.audit_row_change() returns trigger language plpgsql
security definer set search_path=public as $$
declare actor uuid; oldj jsonb; newj jsonb; record_uuid uuid;
begin
 actor := auth.uid();
 if tg_op<>'INSERT' then oldj:=to_jsonb(old); end if;
 if tg_op<>'DELETE' then newj:=to_jsonb(new); end if;
 record_uuid:=coalesce((oldj->>'id')::uuid,(newj->>'id')::uuid);
 insert into public.audit_logs(user_id,table_name,record_id,action,previous,current)
 values(actor,tg_table_name,record_uuid,tg_op,oldj,newj);
 if tg_op='DELETE' then return old; else return new; end if;
end $$;
do $$ declare t text; begin
 foreach t in array array['clients','opportunities','events','tasks','accounts','obligations','settlements','transfers','ingredients','recipes','recipe_items','menus','menu_items','purchases','stock_movements'] loop
   execute format('drop trigger if exists trg_audit on public.%I',t);
   execute format('create trigger trg_audit after insert or update or delete on public.%I for each row execute function public.audit_row_change()',t);
 end loop;
end $$;

create index if not exists idx_opportunity_owner_stage on public.opportunities(user_id,stage);
create index if not exists idx_events_owner_date on public.events(user_id,event_date);
create index if not exists idx_obligations_owner_due on public.obligations(user_id,due_date);
create index if not exists idx_settlement_bill on public.settlements(obligation_id);
create index if not exists idx_ingredients_owner on public.ingredients(user_id);
create index if not exists idx_tasks_owner_due on public.tasks(user_id,due_date);
create index if not exists idx_stock_ingredient on public.stock_movements(ingredient_id);

-- Habilita escuta Postgres Changes nos módulos compartilhados.
-- Somente quem passa RLS recebe os dados visíveis; 'anon' não tem permissão.
do $$ declare t text; begin
 foreach t in array array['clients','opportunities','events','tasks','accounts','obligations','settlements','transfers','ingredients','recipes','recipe_items','menus','menu_items','purchases','stock_movements'] loop
   if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename=t) then
     execute format('alter publication supabase_realtime add table public.%I',t);
   end if;
 end loop;
end $$;
