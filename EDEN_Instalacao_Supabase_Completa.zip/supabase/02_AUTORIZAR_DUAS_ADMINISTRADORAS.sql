-- ÉDEN | PASSO 2: autorizar somente as duas administradoras.
-- Execute APÓS criar os dois logins em Authentication > Users do projeto Éden.
-- Não precisa copiar UID. Este script localiza os IDs pelos e-mails exatos.
-- Não insira senhas neste arquivo.

DO $$
DECLARE
  encontrados integer;
BEGIN
  SELECT COUNT(*) INTO encontrados
  FROM auth.users
  WHERE lower(email) IN ('larathassia@gmail.com', 'amandiisouza@icloud.com');

  IF encontrados <> 2 THEN
    RAISE EXCEPTION 'Éden: encontrei % de 2 contas. Crie ambos os usuários em Authentication > Users antes de executar este passo.', encontrados;
  END IF;

  INSERT INTO public.eden_admins(user_id, display_name)
  SELECT id,
    CASE lower(email)
      WHEN 'larathassia@gmail.com' THEN 'Administradora 01'
      WHEN 'amandiisouza@icloud.com' THEN 'Administradora 02'
    END
  FROM auth.users
  WHERE lower(email) IN ('larathassia@gmail.com', 'amandiisouza@icloud.com')
  ON CONFLICT (user_id) DO UPDATE SET display_name = EXCLUDED.display_name;
END $$;

-- Devem aparecer exatamente duas linhas, uma para cada e-mail.
SELECT u.email, a.display_name, a.user_id, a.created_at
FROM public.eden_admins AS a
JOIN auth.users AS u ON u.id = a.user_id
ORDER BY a.display_name;
